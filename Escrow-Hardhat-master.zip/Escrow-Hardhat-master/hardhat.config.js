require("@nomiclabs/hardhat-waffle");

module.exports = {
  solidity: "0.7.5",
  paths: {
    artifacts: "./app/artifacts",
  }
};
